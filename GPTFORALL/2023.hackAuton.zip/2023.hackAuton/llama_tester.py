import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    pipeline,
)
from peft import PeftModel

def predict_func(inp_str):
    result = pipe(f"{inp_str} <CLSFY>")
    return result

model_name = "NousResearch/Llama-2-7b-chat-hf"
# Load the entire model on the GPU 0
device_map = {"": 0}

base_model = AutoModelForCausalLM.from_pretrained(
    model_name,
    low_cpu_mem_usage=True,
    return_dict=True,
    torch_dtype=torch.float16,
    device_map=device_map,
)

def load_model(model_name):
    model = PeftModel.from_pretrained(base_model, "models_repo/"+new_model)
    model = model.merge_and_unload()
    return model

# Reload tokenizer to save it
print("Loading model..")
tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = "right"

model = load_model
pipe = pipeline(task="text-generation", model=model, tokenizer=tokenizer, max_length=1,return_full_text=False)
preds,labels = predict_func()

# Reload model in FP16 and merge it with LoRA weights
new_model = "llama-2-7b-medical"
model_name = "NousResearch/Llama-2-7b-chat-hf"
# Load the entire model on the GPU 0
device_map = {"": 0}

base_model = AutoModelForCausalLM.from_pretrained(
    model_name,
    low_cpu_mem_usage=True,
    return_dict=True,
    torch_dtype=torch.float16,
    device_map=device_map,
)

model = PeftModel.from_pretrained(base_model, "/content/drive/MyDrive/hackathon/"+new_model)
model = model.merge_and_unload()

# Reload tokenizer to save it
tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = "right"

