# -*- coding: utf-8 -*-
"""
Created on Sun Sep 17 10:10:36 2023

@author: adity
"""
import streamlit as st

st.title("Test your model")
st.write("Instructions for Testing:")
st.write("1. Select a model for testing.")
st.write("2. Enter text for testing.")

# Dropdown for model names
test_model_option = st.selectbox("Select Model for Testing", ["Llama_classifier_v1", "Llama_classifier_v2"])
task_option = st.selectbox("Select Task", ["Translation", 
                                           "Text Classification",
                                           "Question Answering",
                                           "Chat/Generation"])


# Input text field for testing
test_input_text = st.text_area("Enter Text for Testing", "")

if st.button("Submit for Testing"):
    # Perform testing here and display results
    st.write("Testing results:")
    # Add your testing logic here
