# -*- coding: utf-8 -*-
"""
Created on Sun Sep 17 10:09:31 2023

@author: adity
"""

import streamlit as st
import pandas as pd
import time

st.title("GPT for All")
task_option = st.selectbox("Select Task", ["Translation", 
                                           "Text Classification",
                                           "Question Answering",
                                           "Domain teaching"])

st.write("Instructions for Fine tuning:")
st.write("1. Upload your text dataset in CSV format with columns 'source' and 'target'.")
st.write("2. Click 'Start Training' to begin fine-tuning.")

model_option = st.selectbox("Select Model", ["GPT-2", "Llama"])
model_name = st.text_input("Name your model", "")

uploaded_file = st.file_uploader("Upload a CSV file", type=["csv"])

# Display the selected options
st.write("Selected Task:", task_option)
st.write("Selected Model:", model_option)

if uploaded_file is not None:
    # Read the CSV file into a DataFrame
    df = pd.read_csv(uploaded_file)
    
    # Display the DataFrame
    st.write("Uploaded CSV Data:")
    st.write(df)
    
    if st.button("Start Training"):
        with st.spinner("Training in progress..."):
            time.sleep(5)  # Simulating 5 seconds of training time
        if model_option=="Llama":
            from llama_trainer import train_function
            train_function(task_option,df,model_name)

        st.success("Training completed!")

