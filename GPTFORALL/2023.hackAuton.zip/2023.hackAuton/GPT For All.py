# -*- coding: utf-8 -*-
"""
Created on Sun Sep 17 10:08:01 2023

@author: adity
"""

import streamlit as stm
from PIL import Image

stm.set_page_config(page_title = "GPT Fine tuner")
stm.title("GPT for All")
stm.sidebar.success("Select Any Page from here")


image = Image.open('image.PNG')
stm.image(image, width=500) 
